# RYVORA Discord Bot — Railway deployment

Node.js 22 LTS (Dockerfile), discord.js v14. No local PC required once deployed.

## Deploy
1. Generate/reset your Discord bot token in the Discord Developer Portal (Bot > Reset Token). Do not paste it in a message or code repository.
2. In Discord Developer Portal > Bot, enable **Server Members Intent**, which this bot requires for its GuildMembers intent.
3. Create a **private** GitHub repository and upload the contents of this folder to the repository root. DO NOT upload `.env` or `node_modules`.
4. Open https://railway.com/ > New Project > Deploy from GitHub Repo > select the repository. Railway uses the Dockerfile.
5. Select service > Variables. Define `DISCORD_TOKEN`, `CLIENT_ID`, `GUILD_ID`, `TICKET_CATEGORY_ID`, `STAFF_ROLE_ID`, `VERIFY_ROLE_ID` using your real IDs. Optional: `TICKET_IMAGE_URL`, `VERIFY_IMAGE_URL`.
6. In service settings keep the service running continuously (disable sleep/serverless mode if shown), set restart policy to restart on failures or always as your plan supports, and use one replica.
7. Redeploy, inspect Logs. Bot should log registration and a ready message. Test `/setup` and `/verify` in your Discord server.
8. Bot must have Manage Channels and Manage Roles permissions, and its role must be above the verification role. The category/roles must belong to the same Discord server.

The service is a *background worker*. It does not need a public web URL, listening HTTP port, or a healthcheck endpoint.

## Security
- `.env` was intentionally NOT copied from the user-supplied RAR.
- Rotate exposed/old bot tokens.
- Never put the token into this repository or into the website's HTML.
- Only one production process should log in with this bot token unless you implement sharding.
- If Railway shows missing variables, check spelling and copied Discord IDs.

## Limitations
Prepared and syntax checked, not deployed or authenticated. A real Railway/GitHub account and Railway resources are required. 24/7 means infrastructure runs while your PC is off, not a guarantee against outages, restarts or suspension for billing/limits.
