# RYVORA Site — Cloudflare

This is a self-contained static HTML site. It contains its artwork inline in `index.html`.

To publish: Cloudflare dashboard > Workers & Pages > choose the site's service (`floral-math-157b` in the user's screenshot) > New deployment and upload `index.html` if an assets-upload option appears. Alternatively create a Pages project via Direct Upload and upload the folder containing `index.html`.

The site links to https://discord.gg/EKtq2y5UhT for purchases via a ticket opened by the customer. No card payments or automatic ticket generation are enabled.

Keep Cloudflare configured on the correct production domain. The bot itself does not run inside a static Cloudflare site.
